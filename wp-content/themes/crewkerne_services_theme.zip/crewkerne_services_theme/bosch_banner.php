<div class="bosch_banner">
  <div class="bosch_logo">
    <img src="<?php echo get_bloginfo('template_directory'); ?>/images/bcs_logo.png"/>
  </div>
  <div class="bosch_text">
    The Bosch Car Service network works to a Trading Standards Institute approved consumer Code of Practice, guaranteeing you the best possible service and customer care.
  </div>
</div>
